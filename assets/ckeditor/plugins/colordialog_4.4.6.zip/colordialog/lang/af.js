﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'af', {
	clear: 'Herstel',
	highlight: 'Aktief',
	options: 'Kleuropsies',
	selected: 'Geselekteer',
	title: 'Kies kleur'
} );
