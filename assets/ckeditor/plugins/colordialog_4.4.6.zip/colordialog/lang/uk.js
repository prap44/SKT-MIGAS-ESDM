﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'uk', {
	clear: 'Очистити',
	highlight: 'Колір, на який вказує курсор',
	options: 'Опції кольорів',
	selected: 'Обраний колір',
	title: 'Обрати колір'
} );
