﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'eu', {
	clear: 'Garbitu',
	highlight: 'Nabarmendu',
	options: 'Kolore Aukerak',
	selected: 'Hautatutako Kolorea',
	title: 'Kolorea Hautatu'
} );
