﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'sv', {
	clear: 'Rensa',
	highlight: 'Markera',
	options: 'Färgalternativ',
	selected: 'Vald färg',
	title: 'Välj färg'
} );
